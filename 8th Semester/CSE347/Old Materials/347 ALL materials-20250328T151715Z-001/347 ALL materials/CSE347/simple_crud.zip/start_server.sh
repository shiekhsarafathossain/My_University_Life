#!/usr/bin/env bash

php -S localhost:8001
